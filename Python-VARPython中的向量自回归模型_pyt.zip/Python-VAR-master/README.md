# Python-VAR
Vector Autoregressive models in Python
